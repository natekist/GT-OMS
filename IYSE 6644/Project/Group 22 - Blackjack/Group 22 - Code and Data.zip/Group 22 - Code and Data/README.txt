This file provides a description of other files in the current directory.

File: Alternative_Strategies_Results.csv
Description: Simulation test results from �Group 22 � Blackjack � Alternate Strategy.py�

File: Basic_Strategy_Results.csv
Description: Simulation test results from �Group 22 � Blackjack.py�

File: Group 22 � Blackjack.py
Description: Python file containing code for the most basic blackjack strategy

File: Group 22 � Blackjack � Alternate Strategy.py
Description: Python file containing a modified version of �Group 22 � Blackjack.py� that introduces alternative strategies aimed at improving player win percentage.

File: Group 22 � Final Report
Description: The final report writeup containing results from the above .py files and a discussion of the results.
